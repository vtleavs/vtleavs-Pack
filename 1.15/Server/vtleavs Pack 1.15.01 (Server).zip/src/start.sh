#!/usr/bin/env bash
java -jar fabric-server-launch.jar